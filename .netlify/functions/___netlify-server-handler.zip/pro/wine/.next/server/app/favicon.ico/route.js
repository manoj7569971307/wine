var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__03fe02e0._.js")
R.c("server/chunks/[root-of-the-server]__54738107._.js")
R.c("server/chunks/4f487_next_dist_esm_build_templates_app-route_7be73153.js")
R.c("server/chunks/pro_wine__next-internal_server_app_favicon_ico_route_actions_86e92d94.js")
R.m(87023)
module.exports=R.m(87023).exports
