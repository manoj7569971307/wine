var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send-feedback/route.js")
R.c("server/chunks/[root-of-the-server]__fa15c11f._.js")
R.c("server/chunks/[root-of-the-server]__b4e9ab11._.js")
R.c("server/chunks/[root-of-the-server]__54738107._.js")
R.c("server/chunks/4f487_67b04dde._.js")
R.c("server/chunks/pro_wine__next-internal_server_app_api_send-feedback_route_actions_767aff03.js")
R.m(27671)
module.exports=R.m(27671).exports
