module.exports=[3476,(a,b,c)=>{}];

//# sourceMappingURL=pro_wine__next-internal_server_app__not-found_page_actions_7db8bdf1.js.map