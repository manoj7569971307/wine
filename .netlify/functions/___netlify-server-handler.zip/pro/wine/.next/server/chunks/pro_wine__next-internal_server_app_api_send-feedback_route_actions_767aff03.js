module.exports=[82337,(e,o,d)=>{}];

//# sourceMappingURL=pro_wine__next-internal_server_app_api_send-feedback_route_actions_767aff03.js.map