module.exports=[95685,(a,b,c)=>{}];

//# sourceMappingURL=pro_wine__next-internal_server_app__global-error_page_actions_488b83b8.js.map