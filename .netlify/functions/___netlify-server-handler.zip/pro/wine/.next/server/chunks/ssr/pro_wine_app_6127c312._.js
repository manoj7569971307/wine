module.exports=[51809,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},11229,a=>{"use strict";let b={src:a.i(51809).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=pro_wine_app_6127c312._.js.map