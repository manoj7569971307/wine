module.exports=[58882,(a,b,c)=>{}];

//# sourceMappingURL=pro_wine__next-internal_server_app_page_actions_61bc0f29.js.map