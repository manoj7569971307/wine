module.exports=[78771,(e,o,d)=>{}];

//# sourceMappingURL=pro_wine__next-internal_server_app_favicon_ico_route_actions_86e92d94.js.map